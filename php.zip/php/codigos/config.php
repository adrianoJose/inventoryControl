<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'phpoo');
define('DB_USER', 'root');
define('DB_PASS', '');

