<!DOCTYPE html>
<html>
    <body>
        <?php
            require_once 'php/codigos/Categorias.php';

            $categoria = new Categorias();
            foreach ($categoria->findAll() as $key => $value) :
        ?>
      
            <option value='<?php echo $value->id_Categoria ?>'><?php echo $value->nome_Categoria ?></option>
        
        <?php
            endforeach;
        ?>
</body>
</html>